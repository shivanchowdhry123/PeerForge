import {
  StudentProfile,
  Question,
  Answer,
  Community,
  CommunityPost,
  Project,
  SchoolEvent,
  AppNotification,
  Conversation,
  Message,
  ContentReport,
  ContactInquiry
} from '../types';

export const INITIAL_STUDENTS: StudentProfile[] = [
  {
    id: 'user-aakriti',
    name: 'Aakriti Narayan',
    email: 'aakriti.narayan955@gmail.com',
    gmailAccount: 'aakriti.narayan955@gmail.com',
    password: 'Password@123',
    avatar: 'https://api.dicebear.com/7.x/adventurer/svg?seed=Aakriti',
    grade: 'Grade 11',
    section: 'A',
    role: 'developer',
    bio: 'Class 11 Student & Lead App Developer of PeerForge at OPG World School. Passionate about software architecture, collaborative peer networks, algorithms, and STEM innovation.',
    skills: [
      { name: 'Full-Stack Web Development', category: 'Technical', level: 'Advanced', verified: true },
      { name: 'React & TypeScript', category: 'Technical', level: 'Advanced', verified: true },
      { name: 'Python', category: 'Technical', level: 'Advanced', verified: true },
      { name: 'UI/UX Design', category: 'Creative', level: 'Advanced', verified: true },
      { name: 'Peer Tutoring & Leadership', category: 'Leadership & Sports', level: 'Advanced', verified: true },
      { name: 'Mathematics (Calculus)', category: 'Academic', level: 'Advanced', verified: true }
    ],
    interests: ['Software Engineering', 'Robotics', 'Space Science', 'Physics', 'Digital Design'],
    academicStrengths: ['Computer Science', 'Mathematics', 'Physics'],
    projects: [
      {
        id: 'proj-pf',
        title: 'PeerForge Platform',
        description: 'Dynamic peer-to-peer network designed by Class 11 students at OPG World School for students in Classes 9 through 12.',
        role: 'Lead Architect & App Developer',
        status: 'in-progress'
      }
    ],
    achievements: [
      {
        title: 'OPG World School Tech Innovation Lead',
        issuer: 'OPG World School Tech Society',
        date: 'Oct 2026',
        verified: true
      },
      {
        title: 'CBSE Regional Science & Tech Conclave Finalist',
        issuer: 'CBSE Delhi Region',
        date: 'Nov 2025',
        verified: true
      }
    ],
    availability: 'Active & Seeking Projects',
    privacySettings: {
      showGradeToAll: true,
      allowDirectMessages: 'anyone',
      showAchievements: true
    },
    completeness: 100,
    isVerified: true,
    isApproved: true,
    joinedDate: '2026-08-10'
  },
  {
    id: 'user-teacher-mentor',
    name: 'Mr. Rajesh Sharma',
    email: 'teacher.opgworldschool@gmail.com',
    gmailAccount: 'teacher.opgworldschool@gmail.com',
    password: 'Password@123',
    avatar: 'https://api.dicebear.com/7.x/adventurer/svg?seed=TeacherSharma',
    grade: 'Computer Science & Robotics',
    section: 'Faculty',
    role: 'teacher',
    bio: 'Senior Faculty Mentor in Computer Science and Robotics at OPG World School. Advising students across Classes 9–12 on competitive exhibitions, research papers, and technical prototypes.',
    skills: [
      { name: 'Computer Science Mentorship', category: 'Academic', level: 'Advanced', verified: true },
      { name: 'Robotics & Microcontrollers', category: 'Technical', level: 'Advanced', verified: true },
      { name: 'CBSE Curriculum & Research Guidance', category: 'Academic', level: 'Advanced', verified: true },
      { name: 'Project Evaluation', category: 'Academic', level: 'Advanced', verified: true }
    ],
    interests: ['Robotics Education', 'Artificial Intelligence in Pedagogy', 'STEM Competitions'],
    academicStrengths: ['Computer Science', 'Electronics', 'Applied Mathematics'],
    projects: [
      {
        id: 'proj-pf',
        title: 'PeerForge Platform',
        description: 'Dynamic peer-to-peer network designed by Class 11 students at OPG World School for students in Classes 9 through 12.',
        role: 'Faculty Mentor & Academic Advisor',
        status: 'in-progress'
      }
    ],
    achievements: [
      {
        title: 'Distinguished STEM Educator Award',
        issuer: 'OPG World School Administration',
        date: 'Sep 2026',
        verified: true
      }
    ],
    availability: 'Open to Collaborate',
    privacySettings: {
      showGradeToAll: true,
      allowDirectMessages: 'anyone',
      showAchievements: true
    },
    completeness: 100,
    isVerified: true,
    isApproved: true,
    joinedDate: '2026-07-15'
  }
];

export const INITIAL_COMMUNITIES: Community[] = [
  {
    id: 'comm-1',
    name: 'OPG Robotics & AI Society',
    description: 'The epicenter for tinkerers, electronics enthusiasts, autonomous vehicle coders, and competition builders at OPG World School.',
    category: 'STEM & Robotics',
    coverImage: '/src/assets/images/opg_stem_collaboration_1792943471637.jpg',
    membersCount: 2,
    isJoined: true,
    isOfficial: true,
    leaderName: 'Aakriti Narayan (Grade 11)',
    topics: ['Arduino', 'Computer Vision', 'Microcontrollers', 'CBSE Science Fair'],
    createdDate: '2026-08-01'
  }
];

export const INITIAL_POSTS: CommunityPost[] = [
  {
    id: 'post-1',
    communityId: 'comm-1',
    authorId: 'user-aakriti',
    authorName: 'Aakriti Narayan',
    authorGrade: 'Grade 11',
    authorAvatar: 'https://api.dicebear.com/7.x/adventurer/svg?seed=Aakriti',
    content: 'Welcome to PeerForge! Built by Class 11 students at OPG World School to connect students across Classes 9 to 12 for projects, peer doubt solving, and inter-school academic competitions.',
    createdAt: '2 hours ago',
    likes: 2,
    likedBy: ['user-aakriti', 'user-teacher-mentor'],
    commentsCount: 0
  }
];

export const INITIAL_PROJECTS: Project[] = [
  {
    id: 'project-1',
    title: 'PeerForge Academic Portal & Doubt Solver',
    description: 'Dynamic peer-to-peer web system enabling real-time collaboration, peer Q&A doubt resolution, and skill-matching across Classes 9–12.',
    category: 'Software & Web',
    ownerId: 'user-aakriti',
    ownerName: 'Aakriti Narayan',
    ownerGrade: 'Grade 11',
    ownerAvatar: 'https://api.dicebear.com/7.x/adventurer/svg?seed=Aakriti',
    teamSize: 4,
    deadline: '2026-12-15',
    status: 'recruiting',
    requiredSkills: ['React & TypeScript', 'Python', 'UI/UX Design', 'Mathematics (Calculus)'],
    openRoles: [
      { id: 'role-1', title: 'Lead App Developer', requiredSkill: 'React & TypeScript', status: 'filled', assigneeId: 'user-aakriti', assigneeName: 'Aakriti Narayan' },
      { id: 'role-2', title: 'Algorithms & Testing Partner', requiredSkill: 'Python', status: 'open' },
      { id: 'role-3', title: 'Faculty Co-Advisor & Evaluator', requiredSkill: 'Academic Mentorship', status: 'open' }
    ],
    members: [
      { studentId: 'user-aakriti', role: 'Lead Architect', name: 'Aakriti Narayan', avatar: 'https://api.dicebear.com/7.x/adventurer/svg?seed=Aakriti' }
    ],
    applications: [
      {
        id: 'app-teacher-1',
        studentId: 'user-teacher-mentor',
        studentName: 'Mr. Rajesh Sharma (Faculty Mentor)',
        studentGrade: 'Faculty Mentor',
        studentAvatar: 'https://api.dicebear.com/7.x/adventurer/svg?seed=TeacherSharma',
        roleId: 'role-3',
        roleTitle: 'Faculty Co-Advisor & Evaluator',
        note: 'Happy to supervise project documentation, evaluation criteria, and school lab access for testing.',
        status: 'pending',
        createdAt: '1 hour ago'
      }
    ],
    tasks: [
      { id: 'task-1', title: 'Initialize PeerForge repository and responsive layout', completed: true, assignee: 'Aakriti Narayan' },
      { id: 'task-2', title: 'Integrate dynamic profile counter and secure credential management', completed: true, assignee: 'Aakriti Narayan' },
      { id: 'task-3', title: 'Configure upcoming events publishing for Developers & Teachers', completed: true, assignee: 'Aakriti Narayan' }
    ],
    updates: [
      { id: 'up-1', date: 'Oct 25, 2026', text: 'PeerForge launched for OPG World School students with instant account control.' }
    ]
  }
];

export const INITIAL_QUESTIONS: Question[] = [
  {
    id: 'q-1',
    authorId: 'user-aakriti',
    authorName: 'Aakriti Narayan',
    authorGrade: 'Grade 11',
    authorAvatar: 'https://api.dicebear.com/7.x/adventurer/svg?seed=Aakriti',
    title: 'Best problem sets for mastering Class 11 Physics (Mechanics & Rotational Dynamics)?',
    body: 'For mentors and seniors: what references or past competitive olympiad questions build the deepest intuition for rotational equilibrium and conservation of angular momentum?',
    topic: 'Physics & STEM',
    tags: ['Physics', 'Class 11', 'Mechanics', 'Olympiad'],
    createdAt: '3 hours ago',
    upvotes: 2,
    upvotedBy: ['user-aakriti'],
    answersCount: 1,
    acceptedAnswerId: 'ans-1'
  }
];

export const INITIAL_ANSWERS: Answer[] = [
  {
    id: 'ans-1',
    questionId: 'q-1',
    authorId: 'user-teacher-mentor',
    authorName: 'Mr. Rajesh Sharma',
    authorGrade: 'Faculty Mentor',
    authorAvatar: 'https://api.dicebear.com/7.x/adventurer/svg?seed=TeacherSharma',
    body: 'Start with I.E. Irodov problems 1.238 to 1.275 for rigid body dynamics, paired with H.C. Verma Vol 1 Chapter 10 for conceptual clarity on torque vectors and moment of inertia tensors. We have copies in the physics department library.',
    createdAt: '2 hours ago',
    upvotes: 4,
    upvotedBy: ['user-aakriti'],
    isAccepted: true
  }
];

export const INITIAL_EVENTS: SchoolEvent[] = [
  {
    id: 'event-1',
    title: 'OPG Annual Inter-School Science & Innovation Conclave 2026',
    date: 'Nov 14, 2026',
    time: '09:00 AM - 03:30 PM',
    location: 'OPG World School Main Auditorium & Quad',
    category: 'Exhibition',
    description: 'Showcasing over 60 working prototypes in robotics, renewable energy, AI applications, and sustainable agricultural science from students across NCR.',
    organizer: 'OPG Science Faculty & Student Council',
    isOfficial: true,
    rsvpCount: 142,
    isRsvpd: true,
    linkText: 'Register Project'
  }
];

export const INITIAL_CONVERSATIONS: Conversation[] = [
  {
    id: 'conv-1',
    isGroup: false,
    participantIds: ['user-aakriti', 'user-teacher-mentor'],
    lastMessage: {
      text: 'Good morning Aakriti! I reviewed the PeerForge project brief. The robotics lab will be available after 3:30 PM this Friday for hardware integration.',
      senderId: 'user-teacher-mentor',
      timestamp: '10:30 AM'
    },
    updatedAt: '2026-10-26T10:30:00Z',
    projectId: 'project-1'
  }
];

export const INITIAL_MESSAGES: Message[] = [
  {
    id: 'msg-1',
    conversationId: 'conv-1',
    senderId: 'user-aakriti',
    senderName: 'Aakriti Narayan',
    senderAvatar: 'https://api.dicebear.com/7.x/adventurer/svg?seed=Aakriti',
    text: 'Good morning sir! Could we coordinate lab access this Friday to test prototype sensors with our PeerForge team?',
    timestamp: '10:15 AM',
    readBy: ['user-aakriti', 'user-teacher-mentor']
  },
  {
    id: 'msg-2',
    conversationId: 'conv-1',
    senderId: 'user-teacher-mentor',
    senderName: 'Mr. Rajesh Sharma',
    senderAvatar: 'https://api.dicebear.com/7.x/adventurer/svg?seed=TeacherSharma',
    text: 'Good morning Aakriti! I reviewed the PeerForge project brief. The robotics lab will be available after 3:30 PM this Friday for hardware integration.',
    timestamp: '10:30 AM',
    readBy: ['user-aakriti', 'user-teacher-mentor']
  }
];

export const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'notif-1',
    userId: 'user-aakriti',
    type: 'system',
    title: 'Welcome to PeerForge',
    description: 'Your developer account is active. Explore projects, doubt solving, and upcoming events.',
    read: false,
    timestamp: 'Just now',
    actionTab: 'home'
  }
];

export const INITIAL_REPORTS: ContentReport[] = [];

export const INITIAL_CONTACT_INQUIRIES: ContactInquiry[] = [
  {
    id: 'inq-101',
    name: 'Class 10 Tech Representative',
    email: 'techrep.class10@opgworldschool.com',
    category: 'Project Mentorship',
    subject: 'Requesting developer review for automated attendance tracking prototype',
    message: 'We are designing an RFID attendance prototype for our class exhibition and would like guidance from the PeerForge developers on backend integration with Google Sheets or API endpoints.',
    submittedAt: 'Today at 10:15 AM',
    status: 'new'
  }
];

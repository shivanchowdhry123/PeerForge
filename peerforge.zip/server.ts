import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import {
  INITIAL_STUDENTS,
  INITIAL_COMMUNITIES,
  INITIAL_POSTS,
  INITIAL_PROJECTS,
  INITIAL_QUESTIONS,
  INITIAL_ANSWERS,
  INITIAL_EVENTS,
  INITIAL_CONVERSATIONS,
  INITIAL_MESSAGES,
  INITIAL_NOTIFICATIONS,
  INITIAL_REPORTS
} from './src/data/initialData.ts';
import {
  StudentProfile,
  AIMatchResult,
  Question,
  Answer,
  Project,
  Message,
  Conversation,
  Community,
  CommunityPost,
  SchoolEvent,
  AppNotification,
  ContentReport
} from './src/types/index.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Initialize server-side Gemini client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build'
    }
  }
});

// In-Memory Data Store with Initial School Seed
const db = {
  students: [...INITIAL_STUDENTS],
  communities: [...INITIAL_COMMUNITIES],
  posts: [...INITIAL_POSTS],
  projects: [...INITIAL_PROJECTS],
  questions: [...INITIAL_QUESTIONS],
  answers: [...INITIAL_ANSWERS],
  events: [...INITIAL_EVENTS],
  conversations: [...INITIAL_CONVERSATIONS],
  messages: [...INITIAL_MESSAGES],
  notifications: [...INITIAL_NOTIFICATIONS],
  reports: [...INITIAL_REPORTS],
  auditLogs: [
    { id: 'log-1', action: 'System Init', actor: 'System', timestamp: new Date().toISOString(), details: 'Database initialized with verified OPG World School rosters' }
  ]
};

// --- API ROUTES ---

// Health & School Info
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    school: 'OPG World School',
    location: 'Sector 19B, Dwarka, New Delhi',
    platform: 'OPG Connect',
    version: '1.0.0',
    geminiAvailable: Boolean(process.env.GEMINI_API_KEY)
  });
});

// Students List & Search
app.get('/api/students', (req: Request, res: Response) => {
  const { query, grade, skill, category, availability } = req.query;
  let results = [...db.students];

  if (query && typeof query === 'string') {
    const q = query.toLowerCase();
    results = results.filter(s =>
      s.name.toLowerCase().includes(q) ||
      s.bio.toLowerCase().includes(q) ||
      s.skills.some(sk => sk.name.toLowerCase().includes(q)) ||
      s.interests.some(i => i.toLowerCase().includes(q))
    );
  }

  if (grade && typeof grade === 'string' && grade !== 'All') {
    results = results.filter(s => s.grade === grade);
  }

  if (skill && typeof skill === 'string' && skill !== 'All') {
    const sk = skill.toLowerCase();
    results = results.filter(s => s.skills.some(k => k.name.toLowerCase().includes(sk)));
  }

  if (category && typeof category === 'string' && category !== 'All') {
    results = results.filter(s => s.skills.some(k => k.category === category));
  }

  if (availability && typeof availability === 'string' && availability !== 'All') {
    results = results.filter(s => s.availability === availability);
  }

  res.json(results);
});

// Single Student Profile
app.get('/api/students/:id', (req: Request, res: Response) => {
  const student = db.students.find(s => s.id === req.params.id);
  if (!student) {
    return res.status(404).json({ error: 'Student not found' });
  }
  res.json(student);
});

// Update Student Profile
app.put('/api/students/:id', (req: Request, res: Response) => {
  const idx = db.students.findIndex(s => s.id === req.params.id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Student not found' });
  }

  // Calculate completeness
  const updated: StudentProfile = {
    ...db.students[idx],
    ...req.body
  };

  let comp = 50;
  if (updated.bio && updated.bio.length > 20) comp += 15;
  if (updated.skills && updated.skills.length >= 3) comp += 15;
  if (updated.interests && updated.interests.length >= 2) comp += 10;
  if (updated.projects && updated.projects.length >= 1) comp += 10;
  updated.completeness = Math.min(100, comp);

  db.students[idx] = updated;
  res.json(updated);
});

// AI Student Discovery & Semantic Matcher
app.post('/api/ai/match-students', async (req: Request, res: Response) => {
  const { query, targetGrade, categoryFilter } = req.body;

  if (!query || typeof query !== 'string' || !query.trim()) {
    return res.status(400).json({ error: 'Query is required for AI discovery' });
  }

  // Pre-filter candidate list
  let candidatePool = db.students.filter(s => s.isApproved && s.isVerified);
  if (targetGrade && targetGrade !== 'All') {
    candidatePool = candidatePool.filter(s => s.grade === targetGrade);
  }

  // Try real Gemini AI evaluation first
  if (process.env.GEMINI_API_KEY) {
    try {
      const candidatesSummary = candidatePool.map(s => ({
        id: s.id,
        name: s.name,
        grade: s.grade,
        bio: s.bio,
        skills: s.skills.map(sk => `${sk.name} (${sk.level})`),
        interests: s.interests,
        availability: s.availability
      }));

      const systemPrompt = `You are the AI Talent Discovery Assistant for OPG World School's networking platform 'OPG Connect'.
Your task is to analyze a student's natural-language team-search request and match the best candidate students from the school directory.
Follow safety and anti-bias principles: match strictly based on declared skills, proficiency, interests, and availability. Never rank on personal characteristics.

Return JSON in this format:
{
  "extractedRequirements": ["Python", "OpenCV", "Logo Design"],
  "matches": [
    {
      "studentId": "student-1",
      "matchScore": 95,
      "rationale": "Clear, concise 1-2 sentence explanation of why their experience and skills match this request.",
      "matchingSkills": ["Python", "OpenCV"],
      "complementaryRole": "Computer Vision & Hardware Lead"
    }
  ]
}`;

      const userPrompt = `Search query: "${query}"
Candidate Student Profiles:
${JSON.stringify(candidatesSummary, null, 2)}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `${systemPrompt}\n\n${userPrompt}`,
        config: {
          responseMimeType: 'application/json'
        }
      });

      const responseText = response.text;
      if (responseText) {
        const parsed = JSON.parse(responseText.trim());
        const matchedResults: AIMatchResult[] = [];

        if (Array.isArray(parsed.matches)) {
          for (const item of parsed.matches) {
            const student = candidatePool.find(s => s.id === item.studentId);
            if (student) {
              matchedResults.push({
                student,
                matchScore: Number(item.matchScore) || 80,
                rationale: String(item.rationale || 'High alignment with required project proficiencies.'),
                matchingSkills: Array.isArray(item.matchingSkills) ? item.matchingSkills : [],
                complementaryRole: String(item.complementaryRole || 'Core Collaborator')
              });
            }
          }
        }

        if (matchedResults.length > 0) {
          // Sort by match score descending
          matchedResults.sort((a, b) => b.matchScore - a.matchScore);
          return res.json({
            extractedRequirements: parsed.extractedRequirements || [],
            results: matchedResults,
            aiSource: 'gemini-3.8-flash'
          });
        }
      }
    } catch (err) {
      console.warn('Gemini AI match fallback invoked due to:', err);
    }
  }

  // Heuristic Semantic Match Fallback
  const qTerms = query.toLowerCase().split(/\s+/).filter(w => w.length > 2);
  const matchedResults: AIMatchResult[] = candidatePool.map(student => {
    let score = 30; // base score
    const matchingSkills: string[] = [];
    const studentText = `${student.name} ${student.bio} ${student.skills.map(s => s.name).join(' ')} ${student.interests.join(' ')} ${student.academicStrengths.join(' ')}`.toLowerCase();

    student.skills.forEach(skill => {
      const sName = skill.name.toLowerCase();
      if (qTerms.some(t => sName.includes(t) || t.includes(sName))) {
        score += skill.level === 'Advanced' ? 30 : skill.level === 'Intermediate' ? 20 : 10;
        matchingSkills.push(skill.name);
      }
    });

    student.interests.forEach(interest => {
      if (qTerms.some(t => interest.toLowerCase().includes(t))) {
        score += 12;
      }
    });

    if (student.availability === 'Active & Seeking Projects') score += 10;
    score = Math.min(98, score);

    let rationale = `Matched based on demonstrated proficiencies in ${matchingSkills.length > 0 ? matchingSkills.slice(0, 2).join(' and ') : 'related school academic areas'}.`;
    if (matchingSkills.length === 0) {
      rationale = `Candidate has complementary general background in ${student.academicStrengths.slice(0, 2).join(', ')}.`;
    }

    return {
      student,
      matchScore: score,
      rationale,
      matchingSkills: matchingSkills.length > 0 ? matchingSkills : [student.skills[0]?.name || 'Collaboration'],
      complementaryRole: student.skills[0]?.name ? `${student.skills[0].name} Specialist` : 'Peer Collaborator'
    };
  });

  // Sort and filter top matches
  matchedResults.sort((a, b) => b.matchScore - a.matchScore);
  const filtered = matchedResults.filter(r => r.matchScore >= 40);

  res.json({
    extractedRequirements: qTerms.slice(0, 4),
    results: filtered.length > 0 ? filtered : matchedResults.slice(0, 3),
    aiSource: 'semantic-heuristic-engine'
  });
});

// AI Question Assistant (Suggestions & Tag Recommendation)
app.post('/api/ai/question-assistant', async (req: Request, res: Response) => {
  const { title, body } = req.body;

  if (!title || !title.trim()) {
    return res.status(400).json({ error: 'Question title is required' });
  }

  // Find similar existing questions in db
  const words = title.toLowerCase().split(/\s+/).filter((w: string) => w.length > 3);
  const similarQuestions = db.questions.filter(q => {
    const qTitle = q.title.toLowerCase();
    return words.some((w: string) => qTitle.includes(w));
  }).slice(0, 3);

  if (process.env.GEMINI_API_KEY) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `You are an educational writing coach for OPG World School.
Analyze this student question:
Title: "${title}"
Body: "${body || ''}"

Return JSON:
{
  "suggestedTags": ["tag1", "tag2", "tag3"],
  "clarityTips": "A 1-sentence tip on how to make this question clearer for peers.",
  "recommendedTopic": "Computer Science | Mathematics | Science | Social Science & Debate | Academic Exploration | General"
}`,
        config: { responseMimeType: 'application/json' }
      });

      if (response.text) {
        const parsed = JSON.parse(response.text.trim());
        return res.json({
          suggestedTags: parsed.suggestedTags || ['Academics', 'Projects'],
          clarityTips: parsed.clarityTips || 'Provide specific error messages or project context.',
          recommendedTopic: parsed.recommendedTopic || 'General',
          similarExistingQuestions: similarQuestions
        });
      }
    } catch (e) {
      console.warn('Gemini question assistant fallback:', e);
    }
  }

  // Fallback
  res.json({
    suggestedTags: ['Academics', 'Study Group', 'OPG Projects'],
    clarityTips: 'Be specific about what you have already tried and what outcome you are aiming for.',
    recommendedTopic: 'Academic Exploration',
    similarExistingQuestions: similarQuestions
  });
});

// AI Project Brainstormer & Role Planner
app.post('/api/ai/brainstorm-project', async (req: Request, res: Response) => {
  const { idea, category } = req.body;

  if (!idea) {
    return res.status(400).json({ error: 'Project idea is required' });
  }

  if (process.env.GEMINI_API_KEY) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `You are the Student Innovation Project Advisor at OPG World School.
A student wants to start this project:
Idea: "${idea}"
Category: "${category || 'STEM / Innovation'}"

Suggest a high-school feasible project plan with 3 recommended team roles and 4 actionable milestones.
Return JSON:
{
  "projectTitle": "Polished concise project name",
  "refinedDescription": "A concise 2-sentence mission statement.",
  "recommendedRoles": [
    { "roleTitle": "Lead Programmer", "requiredSkill": "Python" },
    { "roleTitle": "Hardware / Sensor Engineer", "requiredSkill": "Arduino / IoT" },
    { "roleTitle": "Visual Designer & Documentation", "requiredSkill": "Graphic Design" }
  ],
  "milestones": [
    "Milestone 1: ...",
    "Milestone 2: ...",
    "Milestone 3: ...",
    "Milestone 4: ..."
  ]
}`,
        config: { responseMimeType: 'application/json' }
      });

      if (response.text) {
        const parsed = JSON.parse(response.text.trim());
        return res.json(parsed);
      }
    } catch (err) {
      console.warn('Gemini brainstorm fallback:', err);
    }
  }

  // Fallback
  res.json({
    projectTitle: `${idea.slice(0, 30)} Prototype`,
    refinedDescription: `An interdisciplinary collaboration project focusing on ${category || 'innovation'} at OPG World School.`,
    recommendedRoles: [
      { roleTitle: 'Project Lead & Architect', requiredSkill: 'Python' },
      { roleTitle: 'Research & Content Lead', requiredSkill: 'Academic Research' },
      { roleTitle: 'Poster & Exhibition Designer', requiredSkill: 'Graphic Design' }
    ],
    milestones: [
      'Define problem scope & consult faculty mentor',
      'Build first MVP / simulation prototype',
      'Run peer feedback trials on campus',
      'Prepare exhibition board for Annual Science Conclave'
    ]
  });
});

// Conversations & Messages
app.get('/api/conversations', (req: Request, res: Response) => {
  const studentId = req.query.studentId as string;
  let list = db.conversations;
  if (studentId) {
    list = list.filter(c => c.participantIds.includes(studentId));
  }
  res.json(list);
});

app.get('/api/conversations/:id/messages', (req: Request, res: Response) => {
  const messages = db.messages.filter(m => m.conversationId === req.params.id);
  res.json(messages);
});

app.post('/api/conversations/:id/messages', (req: Request, res: Response) => {
  const { senderId, senderName, senderAvatar, text, replyTo } = req.body;
  if (!text || !text.trim()) {
    return res.status(400).json({ error: 'Message text required' });
  }

  const newMessage: Message = {
    id: `msg-${Date.now()}`,
    conversationId: req.params.id,
    senderId,
    senderName,
    senderAvatar: senderAvatar || 'https://api.dicebear.com/7.x/bottts/svg?seed=User',
    text,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    reactions: {},
    replyTo,
    readBy: [senderId]
  };

  db.messages.push(newMessage);

  // Update conversation lastMessage
  const conv = db.conversations.find(c => c.id === req.params.id);
  if (conv) {
    conv.lastMessage = {
      text,
      senderId,
      timestamp: newMessage.timestamp
    };
    conv.updatedAt = new Date().toISOString();
  }

  res.status(201).json(newMessage);
});

// React to message
app.post('/api/messages/:id/react', (req: Request, res: Response) => {
  const { emoji, userId } = req.body;
  const msg = db.messages.find(m => m.id === req.params.id);
  if (!msg) return res.status(404).json({ error: 'Message not found' });

  if (!msg.reactions) msg.reactions = {};
  if (!msg.reactions[emoji]) msg.reactions[emoji] = [];

  const existingIdx = msg.reactions[emoji].indexOf(userId);
  if (existingIdx > -1) {
    msg.reactions[emoji].splice(existingIdx, 1);
    if (msg.reactions[emoji].length === 0) {
      delete msg.reactions[emoji];
    }
  } else {
    msg.reactions[emoji].push(userId);
  }

  res.json(msg);
});

// Create or get direct conversation
app.post('/api/conversations/direct', (req: Request, res: Response) => {
  const { currentUserId, targetUserId } = req.body;
  let conv = db.conversations.find(c =>
    !c.isGroup &&
    c.participantIds.includes(currentUserId) &&
    c.participantIds.includes(targetUserId)
  );

  if (!conv) {
    conv = {
      id: `conv-${Date.now()}`,
      isGroup: false,
      participantIds: [currentUserId, targetUserId],
      updatedAt: new Date().toISOString()
    };
    db.conversations.unshift(conv);
  }

  res.json(conv);
});

// Questions & Answers
app.get('/api/questions', (req: Request, res: Response) => {
  const { topic, search, sort } = req.query;
  let list = [...db.questions];

  if (topic && topic !== 'All') {
    list = list.filter(q => q.topic === topic);
  }

  if (search && typeof search === 'string') {
    const s = search.toLowerCase();
    list = list.filter(q =>
      q.title.toLowerCase().includes(s) ||
      q.body.toLowerCase().includes(s) ||
      q.tags.some(t => t.toLowerCase().includes(s))
    );
  }

  if (sort === 'unanswered') {
    list = list.filter(q => q.answersCount === 0);
  } else if (sort === 'discussed') {
    list.sort((a, b) => b.answersCount - a.answersCount);
  } else {
    // Default newest
    list.sort((a, b) => b.id.localeCompare(a.id));
  }

  res.json(list);
});

app.post('/api/questions', (req: Request, res: Response) => {
  const { authorId, authorName, authorGrade, authorAvatar, title, body, topic, tags } = req.body;
  if (!title || !body) {
    return res.status(400).json({ error: 'Title and body required' });
  }

  const newQ: Question = {
    id: `q-${Date.now()}`,
    authorId,
    authorName,
    authorGrade: authorGrade || 'Student',
    authorAvatar: authorAvatar || 'https://api.dicebear.com/7.x/bottts/svg?seed=Q',
    title,
    body,
    topic: topic || 'General',
    tags: Array.isArray(tags) ? tags : ['Academics'],
    createdAt: 'Just now',
    upvotes: 0,
    upvotedBy: [],
    answersCount: 0
  };

  db.questions.unshift(newQ);
  res.status(201).json(newQ);
});

app.get('/api/questions/:id/answers', (req: Request, res: Response) => {
  const answers = db.answers.filter(a => a.questionId === req.params.id);
  res.json(answers);
});

app.post('/api/questions/:id/answers', (req: Request, res: Response) => {
  const { authorId, authorName, authorGrade, authorAvatar, body } = req.body;
  if (!body) return res.status(400).json({ error: 'Answer body required' });

  const newAns: Answer = {
    id: `ans-${Date.now()}`,
    questionId: req.params.id,
    authorId,
    authorName,
    authorGrade: authorGrade || 'Student',
    authorAvatar: authorAvatar || 'https://api.dicebear.com/7.x/bottts/svg?seed=A',
    body,
    createdAt: 'Just now',
    upvotes: 0,
    upvotedBy: [],
    isAccepted: false
  };

  db.answers.push(newAns);

  const q = db.questions.find(item => item.id === req.params.id);
  if (q) {
    q.answersCount += 1;
    // Push notification to question author if different
    if (q.authorId !== authorId) {
      db.notifications.unshift({
        id: `notif-${Date.now()}`,
        userId: q.authorId,
        type: 'answer',
        title: 'New answer on your question',
        description: `${authorName} answered: "${q.title.slice(0, 40)}..."`,
        read: false,
        timestamp: 'Just now',
        actionTab: 'qa'
      });
    }
  }

  res.status(201).json(newAns);
});

app.post('/api/answers/:id/upvote', (req: Request, res: Response) => {
  const { userId } = req.body;
  const ans = db.answers.find(a => a.id === req.params.id);
  if (!ans) return res.status(404).json({ error: 'Answer not found' });

  const existing = ans.upvotedBy.indexOf(userId);
  if (existing > -1) {
    ans.upvotedBy.splice(existing, 1);
    ans.upvotes = Math.max(0, ans.upvotes - 1);
  } else {
    ans.upvotedBy.push(userId);
    ans.upvotes += 1;
  }

  res.json(ans);
});

app.post('/api/questions/:id/accept-answer', (req: Request, res: Response) => {
  const { answerId } = req.body;
  const q = db.questions.find(item => item.id === req.params.id);
  if (!q) return res.status(404).json({ error: 'Question not found' });

  q.acceptedAnswerId = answerId;
  db.answers.forEach(a => {
    if (a.questionId === req.params.id) {
      a.isAccepted = (a.id === answerId);
    }
  });

  res.json({ success: true, acceptedAnswerId: answerId });
});

// Communities
app.get('/api/communities', (req: Request, res: Response) => {
  res.json(db.communities);
});

app.post('/api/communities/:id/join', (req: Request, res: Response) => {
  const comm = db.communities.find(c => c.id === req.params.id);
  if (!comm) return res.status(404).json({ error: 'Community not found' });

  comm.isJoined = !comm.isJoined;
  comm.membersCount += comm.isJoined ? 1 : -1;
  res.json(comm);
});

app.get('/api/communities/:id/posts', (req: Request, res: Response) => {
  const posts = db.posts.filter(p => p.communityId === req.params.id);
  res.json(posts);
});

app.post('/api/communities/:id/posts', (req: Request, res: Response) => {
  const { authorId, authorName, authorGrade, authorAvatar, content, poll } = req.body;
  if (!content) return res.status(400).json({ error: 'Content required' });

  const newPost: CommunityPost = {
    id: `post-${Date.now()}`,
    communityId: req.params.id,
    authorId,
    authorName,
    authorGrade: authorGrade || 'Student',
    authorAvatar: authorAvatar || 'https://api.dicebear.com/7.x/bottts/svg?seed=Post',
    content,
    createdAt: 'Just now',
    likes: 0,
    likedBy: [],
    commentsCount: 0,
    poll
  };

  db.posts.unshift(newPost);
  res.status(201).json(newPost);
});

app.post('/api/posts/:id/like', (req: Request, res: Response) => {
  const { userId } = req.body;
  const post = db.posts.find(p => p.id === req.params.id);
  if (!post) return res.status(404).json({ error: 'Post not found' });

  const idx = post.likedBy.indexOf(userId);
  if (idx > -1) {
    post.likedBy.splice(idx, 1);
    post.likes = Math.max(0, post.likes - 1);
  } else {
    post.likedBy.push(userId);
    post.likes += 1;
  }
  res.json(post);
});

app.post('/api/posts/:id/poll-vote', (req: Request, res: Response) => {
  const { optionIndex, userId } = req.body;
  const post = db.posts.find(p => p.id === req.params.id);
  if (!post || !post.poll) return res.status(404).json({ error: 'Poll not found' });

  const opt = post.poll.options[optionIndex];
  if (!opt) return res.status(400).json({ error: 'Invalid option' });

  // Remove vote from other options if any
  post.poll.options.forEach(o => {
    const uIdx = o.voters.indexOf(userId);
    if (uIdx > -1) {
      o.voters.splice(uIdx, 1);
      o.votes = Math.max(0, o.votes - 1);
    }
  });

  opt.voters.push(userId);
  opt.votes += 1;

  res.json(post);
});

// Projects & Collaboration
app.get('/api/projects', (req: Request, res: Response) => {
  const { status, category } = req.query;
  let list = db.projects;
  if (status && status !== 'All') {
    list = list.filter(p => p.status === status);
  }
  if (category && category !== 'All') {
    list = list.filter(p => p.category === category);
  }
  res.json(list);
});

app.post('/api/projects', (req: Request, res: Response) => {
  const { title, description, category, ownerId, ownerName, ownerGrade, ownerAvatar, requiredSkills, openRoles, deadline } = req.body;
  if (!title || !description) return res.status(400).json({ error: 'Title and description required' });

  const newProj: Project = {
    id: `project-${Date.now()}`,
    title,
    description,
    category: category || 'General Innovation',
    ownerId,
    ownerName,
    ownerGrade: ownerGrade || 'Student',
    ownerAvatar: ownerAvatar || 'https://api.dicebear.com/7.x/bottts/svg?seed=P',
    teamSize: (openRoles?.length || 2) + 1,
    deadline: deadline || '2026-12-31',
    status: 'recruiting',
    requiredSkills: requiredSkills || [],
    openRoles: openRoles || [
      { id: `role-${Date.now()}-1`, title: 'Core Collaborator', requiredSkill: 'Teamwork', status: 'open' }
    ],
    members: [
      { studentId: ownerId, role: 'Project Owner', name: ownerName, avatar: ownerAvatar }
    ],
    applications: [],
    tasks: [
      { id: `task-${Date.now()}-1`, title: 'Kickoff meeting & problem statement', completed: false }
    ],
    updates: [
      { id: `up-${Date.now()}-1`, date: 'Today', text: 'Project established and open for team applications.' }
    ]
  };

  db.projects.unshift(newProj);
  res.status(201).json(newProj);
});

app.post('/api/projects/:id/apply', (req: Request, res: Response) => {
  const { studentId, studentName, studentGrade, studentAvatar, roleId, roleTitle, note } = req.body;
  const project = db.projects.find(p => p.id === req.params.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });

  const application = {
    id: `app-${Date.now()}`,
    studentId,
    studentName,
    studentGrade: studentGrade || 'Student',
    studentAvatar: studentAvatar || 'https://api.dicebear.com/7.x/bottts/svg?seed=App',
    roleId,
    roleTitle,
    note: note || '',
    status: 'pending' as const,
    createdAt: 'Just now'
  };

  project.applications.push(application);

  // Notify project owner
  db.notifications.unshift({
    id: `notif-${Date.now()}`,
    userId: project.ownerId,
    type: 'invite',
    title: 'New Project Application',
    description: `${studentName} applied for ${roleTitle} on "${project.title.slice(0, 30)}..."`,
    read: false,
    timestamp: 'Just now',
    actionTab: 'projects'
  });

  res.status(201).json(application);
});

app.post('/api/projects/:id/applications/:appId', (req: Request, res: Response) => {
  const { action } = req.body; // 'accepted' | 'rejected'
  const project = db.projects.find(p => p.id === req.params.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });

  const appItem = project.applications.find(a => a.id === req.params.appId);
  if (!appItem) return res.status(404).json({ error: 'Application not found' });

  appItem.status = action;

  if (action === 'accepted') {
    // Add to project members
    project.members.push({
      studentId: appItem.studentId,
      role: appItem.roleTitle,
      name: appItem.studentName,
      avatar: appItem.studentAvatar
    });

    // Mark role filled
    const role = project.openRoles.find(r => r.id === appItem.roleId);
    if (role) {
      role.status = 'filled';
      role.assigneeId = appItem.studentId;
      role.assigneeName = appItem.studentName;
    }

    // Add notification to accepted student
    db.notifications.unshift({
      id: `notif-${Date.now()}`,
      userId: appItem.studentId,
      type: 'invite',
      title: 'Application Accepted!',
      description: `You have joined the team for "${project.title}" as ${appItem.roleTitle}.`,
      read: false,
      timestamp: 'Just now',
      actionTab: 'projects'
    });
  }

  res.json({ success: true, application: appItem, project });
});

// Events & Announcements
app.get('/api/events', (req: Request, res: Response) => {
  res.json(db.events);
});

app.post('/api/events/:id/rsvp', (req: Request, res: Response) => {
  const event = db.events.find(e => e.id === req.params.id);
  if (!event) return res.status(404).json({ error: 'Event not found' });

  event.isRsvpd = !event.isRsvpd;
  event.rsvpCount += event.isRsvpd ? 1 : -1;
  res.json(event);
});

// Notifications
app.get('/api/notifications', (req: Request, res: Response) => {
  const userId = req.query.userId as string;
  let list = db.notifications;
  if (userId) {
    list = list.filter(n => n.userId === userId || n.userId === 'all');
  }
  res.json(list);
});

app.post('/api/notifications/mark-read', (req: Request, res: Response) => {
  const { id, userId } = req.body;
  if (id) {
    const notif = db.notifications.find(n => n.id === id);
    if (notif) notif.read = true;
  } else if (userId) {
    db.notifications.filter(n => n.userId === userId).forEach(n => n.read = true);
  }
  res.json({ success: true });
});

// Content Moderation & Reporting
app.post('/api/reports', (req: Request, res: Response) => {
  const { reporterId, reportedUserId, reportedUserName, targetType, targetId, reason, details } = req.body;
  const newReport: ContentReport = {
    id: `rep-${Date.now()}`,
    reporterId,
    reportedUserId,
    reportedUserName: reportedUserName || 'Anonymous',
    targetType,
    targetId,
    reason: reason || 'Community Guidelines Violation',
    details: details || '',
    status: 'pending',
    timestamp: new Date().toLocaleDateString()
  };

  db.reports.unshift(newReport);
  db.auditLogs.unshift({
    id: `log-${Date.now()}`,
    action: 'Report Submitted',
    actor: reporterId,
    timestamp: new Date().toISOString(),
    details: `Report against ${reportedUserName} for ${reason}`
  });

  res.status(201).json(newReport);
});

// Admin Dashboard Endpoints
app.get('/api/admin/overview', (req: Request, res: Response) => {
  res.json({
    totalStudents: db.students.length,
    verifiedStudents: db.students.filter(s => s.isVerified).length,
    activeProjects: db.projects.filter(p => p.status === 'recruiting' || p.status === 'in-progress').length,
    totalQuestions: db.questions.length,
    pendingReports: db.reports.filter(r => r.status === 'pending').length,
    reports: db.reports,
    auditLogs: db.auditLogs.slice(0, 15)
  });
});

app.post('/api/admin/reports/:id/resolve', (req: Request, res: Response) => {
  const { action, note } = req.body;
  const rep = db.reports.find(r => r.id === req.params.id);
  if (!rep) return res.status(404).json({ error: 'Report not found' });

  rep.status = action === 'dismiss' ? 'dismissed' : 'action_taken';
  db.auditLogs.unshift({
    id: `log-${Date.now()}`,
    action: `Report ${action}`,
    actor: 'Admin',
    timestamp: new Date().toISOString(),
    details: `Report ${rep.id} resolved with action ${action}. Note: ${note || 'None'}`
  });

  res.json({ success: true, report: rep });
});

// Student Data Export (DPDP Compliance)
app.get('/api/students/:id/export-data', (req: Request, res: Response) => {
  const student = db.students.find(s => s.id === req.params.id);
  if (!student) return res.status(404).json({ error: 'Student not found' });

  const userMessages = db.messages.filter(m => m.senderId === student.id);
  const userProjects = db.projects.filter(p => p.ownerId === student.id || p.members.some(m => m.studentId === student.id));
  const userQuestions = db.questions.filter(q => q.authorId === student.id);

  res.json({
    school: 'OPG World School',
    studentProfile: student,
    exportedAt: new Date().toISOString(),
    activitySummary: {
      messagesCount: userMessages.length,
      projectsInvolved: userProjects.length,
      questionsAsked: userQuestions.length
    },
    privacyDeclaration: 'Data generated strictly within the OPG Connect school firewall under School Student Data Protection policies.'
  });
});

// Start server with Vite middleware in development or static in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`OPG Connect full-stack server running on http://localhost:${PORT}`);
  });
}

startServer();
